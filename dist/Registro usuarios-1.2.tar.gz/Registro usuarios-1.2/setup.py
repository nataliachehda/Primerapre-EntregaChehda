from setuptools import setup

setup(
    name="Registro usuarios",
    version="1.2",
    description="El proyecto actualizó sus funciones y ahora se pueden realizar compras de celulares",
    author="Natalia Chehda",
    author_email="nataliachehda@gmail.com",
    packages=["package1"]
)